// improved-script.js

document.getElementById('menu-toggle').addEventListener('click', function () {
  document.getElementById('nav-menu').classList.toggle('show');
});
